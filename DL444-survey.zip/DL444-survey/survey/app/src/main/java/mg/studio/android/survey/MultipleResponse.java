package mg.studio.android.survey;

import java.util.ArrayList;

final class MultipleResponse implements ISurveyResponse {

    @Override
    public String getResponse() {
        StringBuilder builder = new StringBuilder();
        for (String r : responses) {
            builder.append(r).append("\n");
        }
        return builder.toString().trim();
    }

    @Override
    public void setResponse(String response) {
        if (responses.contains(response)) {
            responses.remove(response);
        } else {
            responses.add(response);
        }
    }

    @Override
    public Boolean hasResponse() {
        return responses.size() != 0;
    }

    private ArrayList<String> responses = new ArrayList<>();
}
