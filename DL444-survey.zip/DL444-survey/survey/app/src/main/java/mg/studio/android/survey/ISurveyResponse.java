package mg.studio.android.survey;

import java.io.Serializable;

interface ISurveyResponse extends Serializable {
    String getResponse();
    void setResponse(String response);
    Boolean hasResponse();
}
