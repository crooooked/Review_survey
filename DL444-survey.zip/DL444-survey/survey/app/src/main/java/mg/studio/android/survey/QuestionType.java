package mg.studio.android.survey;

enum QuestionType {
    Single,
    Multiple,
    Text,
    None
}
