package mg.studio.android.survey;

final class CachedResponse implements ISurveyResponse {
    public CachedResponse(String response) {
        this.response = response;
    }

    @Override
    public String getResponse() {
        return response;
    }

    @Override
    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public Boolean hasResponse() {
        return true;
    }

    private String response = "";
}
