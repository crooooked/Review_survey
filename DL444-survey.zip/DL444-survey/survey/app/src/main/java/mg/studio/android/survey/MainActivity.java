package mg.studio.android.survey;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean resultCached = readResultCache();
        if (resultCached) {
            navigateToSummary();
        }

        setContentView(R.layout.welcome);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 0) {
            if (!writeResultCache()) {
                Toast.makeText(this, R.string.cacheFailed, Toast.LENGTH_LONG).show();
            }
            navigateToSummary();
        }
    }

    public void next(View sender) {
        if (finalized) {
            return;
        }
        ISurveyResponse response;
        switch (questionTypes[page]) {
            case Single:
                response = new SingleResponse();
                ViewGroup opts = findViewById(R.id.opts);
                for (int i = 0; i < opts.getChildCount(); i++) {
                    RadioButton optBtn = (RadioButton)opts.getChildAt(i);
                    if (optBtn.isChecked()) {
                        response.setResponse(optBtn.getText().toString());
                        break;
                    }
                }
                if (response.hasResponse()) {
                    responses.add(response);
                } else {
                    return;
                }
                break;
            case Multiple:
                response = new MultipleResponse();
                ViewGroup checks = findViewById(R.id.opts);
                for (int i = 0; i < checks.getChildCount(); i++) {
                    CheckBox check = (CheckBox)checks.getChildAt(i);
                    if (check.isChecked()) {
                        response.setResponse(check.getText().toString());
                    }
                }
                if (response.hasResponse()) {
                    responses.add(response);
                } else {
                    return;
                }
                break;
            case Text:
                response = new SingleResponse();
                EditText inputBox = findViewById(R.id.inputBox);
                response.setResponse(inputBox.getText().toString());
                if (response.hasResponse()) {
                    responses.add(response);
                } else {
                    return;
                }
                break;
        }

        page++;
        if (page < pageIds.length) {
            setLayout(pageIds[page]);
        } else {
            finalized = true;
            responses.remove(0);
            requestExternalWritePermission();
        }
    }

    private void setLayout(int layoutId) {
        setContentView(layoutId);
    }

    private boolean readResultCache() {
        File file = new File(this.getFilesDir(), "result.json");
        try {
            FileInputStream input = new FileInputStream(file);
            byte[] encoded = new byte[(int)file.length()];
            input.read(encoded);
            input.close();
            String json = new String(encoded);
            JSONArray responsesArray = new JSONArray(json);
            for (int i = 0; i < responsesArray.length(); i++) {
                String r = responsesArray.getString(i);
                responses.add(new CachedResponse(r));
            }
            return true;
        } catch (FileNotFoundException ex) {
            Log.i("Result Load", "Result load failed because the file was not found.", ex);
            return false;
        } catch (IOException ex) {
            Log.e("Result Load", "Result load failed because IO operation failed.", ex);
            return false;
        } catch (JSONException ex) {
            Log.e("Result Load", "Result load failed because deserialization failed.", ex);
            return false;
        }
    }

    private void requestExternalWritePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.WRITE_EXTERNAL_STORAGE }, 0);
        }
    }

    private boolean writeResultCache()
    {
        String json = jsonSerializeResults();
        byte[] content = json.getBytes(Charset.forName("utf-8"));
        File file = new File(this.getFilesDir(), "result.json");
        boolean result = writeFile(file, content);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            && Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            file = new File(Environment.getExternalStorageDirectory(), "svyu-result.json");
            result = result & writeFile(file, content);
        }

        return result;
    }

    private boolean writeFile(File file, byte[] content) {
        try {
            if (file.exists()) {
                file.delete();
            }
            file.createNewFile();
            FileOutputStream output = new FileOutputStream(file);
            output.write(content);
            output.flush();
            output.close();
            return true;
        } catch (IOException ex) {
            Log.e("Result Save", "Result save failed because IO operation failed.", ex);
            return false;
        }
    }

    private String jsonSerializeResults() {
        JSONArray root = new JSONArray();
        for (ISurveyResponse r : responses) {
            root.put(r.getResponse());
        }
        return root.toString();
    }

    private void navigateToSummary() {
        Intent navIntent = new Intent(this, SummaryActivity.class);
        navIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        navIntent.putExtra(getPackageName() + ".responses", responses);
        startActivity(navIntent);
        this.finish();
    }

    private int page = 0;
    private boolean finalized = false;

    private int[] pageIds = new int[] {
        R.layout.welcome,
        R.layout.question_one,
        R.layout.question_two,
        R.layout.question_three,
        R.layout.question_four,
        R.layout.question_five,
        R.layout.question_six,
        R.layout.question_seven,
        R.layout.question_eight,
        R.layout.question_nine,
        R.layout.question_ten,
        R.layout.question_eleven,
        R.layout.question_twelve,
        R.layout.finish_survey
    };

    private QuestionType[] questionTypes = new QuestionType[] {
        QuestionType.Multiple,
        QuestionType.Single,
        QuestionType.Single,
        QuestionType.Single,
        QuestionType.Multiple,
        QuestionType.Multiple,
        QuestionType.Text,
        QuestionType.Single,
        QuestionType.Single,
        QuestionType.Single,
        QuestionType.Single,
        QuestionType.Single,
        QuestionType.Single,
        QuestionType.None
    };

    private ArrayList<ISurveyResponse> responses = new ArrayList<>();
}
