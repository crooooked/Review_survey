package mg.studio.android.survey;

final class SingleResponse implements ISurveyResponse {

    @Override
    public String getResponse() {
        return response;
    }

    @Override
    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public Boolean hasResponse() {
        return !response.trim().isEmpty();
    }

    private String response = "";
}
